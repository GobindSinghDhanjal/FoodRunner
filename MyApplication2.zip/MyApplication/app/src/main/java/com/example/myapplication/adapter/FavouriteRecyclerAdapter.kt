package com.example.myapplication.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.database.RestaurantEntity
import com.squareup.picasso.Picasso

class FavouriteRecyclerAdapter(val context: Context, val restaurantList : List<RestaurantEntity>) : RecyclerView.Adapter<FavouriteRecyclerAdapter.FavouriteViewHolder>() {

    class FavouriteViewHolder(view: View): RecyclerView.ViewHolder(view)
    {
        val txtRestaurantName : TextView = view.findViewById(R.id.txtRestaurantName)
        val txtCostPerPerson : TextView = view.findViewById(R.id.txtCostPerPerson)
        val txtRating : TextView = view.findViewById(R.id.txtRating)
        //val txtIconFavourite : TextView = view.findViewById(R.id.txtIconFavorite)
        val imgRestaurantImage : ImageView = view.findViewById(R.id.imgRestaurantImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavouriteViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_favourite_single_row,parent,false)

        return FavouriteViewHolder(view)

    }

    override fun onBindViewHolder(holder: FavouriteViewHolder, position: Int) {

        val restaurant = restaurantList[position]

        holder.txtRestaurantName.text = restaurant.resName
        holder.txtRating.text = restaurant.resRating
        holder.txtCostPerPerson.text = ("₹ "+restaurant.costPerPerson+"/per person")
        Picasso.get().load(restaurant.ImageUrl).into(holder.imgRestaurantImage)

    }

    override fun getItemCount(): Int {
        return restaurantList.size
    }

}