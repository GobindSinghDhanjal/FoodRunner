package com.example.myapplication.model

data class Restaurant (
    val resId:String,
    val resName:String,
    val resRating:String,
    val cost_for_one:String,
    val resImage:String
        )