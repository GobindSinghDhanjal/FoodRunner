package com.example.myapplication.adapter

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BlendMode
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.graphics.toColor
import androidx.core.graphics.toColorLong
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.myapplication.R
import com.example.myapplication.database.RestaurantDatabase
import com.example.myapplication.database.RestaurantEntity
import com.example.myapplication.fragments.HomePageFragment
import com.example.myapplication.model.Restaurant
import com.google.android.material.internal.NavigationMenuItemView
import com.squareup.picasso.Picasso
import kotlin.properties.Delegates


class HomePageAdapter(val context: Context, val itemList: ArrayList<Restaurant>, val restaurantEntity: RestaurantEntity) : RecyclerView.Adapter<HomePageAdapter.HomePageViewHolder>() {


    class HomePageViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val txtRestaurantName: TextView = view.findViewById(R.id.txtRestaurantName)
        val txtCostPerPerson: TextView = view.findViewById(R.id.txtCostPerPerson)
        val txtRating: TextView = view.findViewById(R.id.txtRating)
        var btnFavourite: AppCompatButton = view.findViewById(R.id.btnFavorite)
        val imgRestaurantImage: ImageView = view.findViewById(R.id.imgRestaurantImage)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomePageViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_home_single_row, parent, false)


        val checkFav = DBAsyncTask(context, restaurantEntity, 1).execute()
        val isFav = checkFav.get()

        if (isFav) {
            HomePageViewHolder(view).btnFavourite.setBackgroundResource(R.drawable.ic_vector_favorite)

        } else {

            HomePageViewHolder(view).btnFavourite.setBackgroundResource(R.drawable.ic_vector_not_favorite)

        }

        HomePageViewHolder(view).btnFavourite.setOnClickListener {

            val id = HomePageViewHolder(view).btnFavourite.findFocus()
            println("id is $id")

            if (!DBAsyncTask(context, restaurantEntity, 1).execute().get()) {
                val async = DBAsyncTask(context, restaurantEntity, 2).execute()
                val result = async.get()

                println("result : $result")

                if (result) {
                    println("result 2 : $result")
                    Toast.makeText(context, "Restaurant Added to Favorites", Toast.LENGTH_SHORT).show()

                    HomePageViewHolder(view).btnFavourite.setBackgroundResource(R.drawable.ic_vector_favorite)
                } else {
                    Toast.makeText(context, "Some Error Occured", Toast.LENGTH_SHORT).show()
                }
            } else {
                val async = DBAsyncTask(context, restaurantEntity, 3).execute()
                val result = async.get()

                if (result) {
                    println("result 3 : $result")
                    Toast.makeText(context, "Restaurant Removed From Favorites", Toast.LENGTH_SHORT).show()

                    HomePageViewHolder(view).btnFavourite.setBackgroundResource(R.drawable.ic_vector_not_favorite)

                } else {
                    Toast.makeText(context, "Some Error Occured", Toast.LENGTH_SHORT).show()
                }
            }

        }


        return HomePageViewHolder(view)
    }


    override fun onBindViewHolder(holder: HomePageViewHolder, position: Int) {

        val res = itemList[position]

        println("Position $position Res Positon ${(restaurantEntity.res_id)}")
        holder.txtRestaurantName.text = res.resName
        holder.txtCostPerPerson.text = ("₹ " + res.cost_for_one + "/per person")
        holder.txtRating.text = res.resRating
        Picasso.get().load(res.resImage).error(R.drawable.food).into(holder.imgRestaurantImage)


    }


    override fun getItemCount(): Int {

        return itemList.size
    }


    class DBAsyncTask(val context: Context, val restaurantEntity: RestaurantEntity, val mode: Int) : AsyncTask<Void, Void, Boolean>() {
        //lateinit var restaurantEntity : RestaurantEntity

        val db = Room.databaseBuilder(context, RestaurantDatabase::class.java, "res-db").build()

        override fun doInBackground(vararg params: Void?): Boolean {


            when (mode) {
                1 -> {
                    val res: RestaurantEntity? = db.restaurantDao().getResById(restaurantEntity.res_id.toString())
                    db.close()
                    return res != null
                }

                2 -> {
                    db.restaurantDao().insertRestaurant(restaurantEntity)
                    db.close()
                    return true
                }

                3 -> {
                    db.restaurantDao().deleteRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
            }
            return false
        }

    }
}