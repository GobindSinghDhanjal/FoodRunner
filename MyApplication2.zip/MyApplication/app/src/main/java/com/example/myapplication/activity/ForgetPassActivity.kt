package com.example.myapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.myapplication.R

class ForgetPassActivity : AppCompatActivity() {

    lateinit var etMobileForget : EditText
    lateinit var etEmailForget : EditText
    lateinit var btnNextForget : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_pass)

        btnNextForget = findViewById(R.id.btnNextForget)

        btnNextForget.setOnClickListener {

            etMobileForget = findViewById(R.id.etMobileForget)
            etEmailForget = findViewById(R.id.etEmailForget)

            val intent = Intent(this, EmptyActivity::class.java)
            intent.putExtra("MobileForget",etMobileForget.text.toString())
            intent.putExtra("EmailForget",etEmailForget.text.toString())
            intent.putExtra("ForgetPass",true)
            startActivity(intent)
            finish()

        }

    }
}