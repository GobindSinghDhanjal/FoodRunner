package com.example.myapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.myapplication.R

class RegisterActivity : AppCompatActivity() {

    lateinit var btnBackRegister : Button
    lateinit var btnRegister : Button
    lateinit var etName : EditText
    lateinit var etEmail : EditText
    lateinit var etPhone : EditText
    lateinit var etDeliveryAdd : EditText
    lateinit var etPasswordRegister : EditText
    lateinit var etConfirmPasswordRegister : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        btnBackRegister = findViewById(R.id.btnBackRegister)
        btnRegister = findViewById(R.id.btnRegister)


        btnBackRegister.setOnClickListener {

            val back = Intent(this, LoginActivity::class.java)
            startActivity(back)
            finish()

        }

        btnRegister.setOnClickListener {

            etName = findViewById(R.id.etName)
            etPhone = findViewById(R.id.etPhone)
            etDeliveryAdd = findViewById(R.id.etDeliveryAdd)
            etPasswordRegister = findViewById(R.id.etPasswordRegister)
            etConfirmPasswordRegister = findViewById(R.id.etConfirmPasswordRegister)
            etEmail = findViewById(R.id.etEmail)

            val intentRegister = Intent(this, EmptyActivity::class.java)

            if((etPasswordRegister.text.toString()==etConfirmPasswordRegister.text.toString()))
            {
                Toast.makeText(this,"Register Successfully",Toast.LENGTH_LONG).show()
                intentRegister.putExtra("Name",etName.text.toString())
                intentRegister.putExtra("Phone",etPhone.text.toString())
                intentRegister.putExtra("Email",etEmail.text.toString())
                intentRegister.putExtra("DeliveryAdd",etDeliveryAdd.text.toString())
                intentRegister.putExtra("Password",etPasswordRegister.text.toString())
                intentRegister.putExtra("RegisterTrue",true)
                startActivity(intentRegister)
                finish()
            }
            else
            {
                Toast.makeText(this,"Password Doesn't match",Toast.LENGTH_LONG).show()
            }

        }

    }
}